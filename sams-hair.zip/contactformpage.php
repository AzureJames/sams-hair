<?php /*Template Name: ContactFromPage */


get_header();
?>

<div class="testing">
    <h1>CONTACT ME</h1>

    <?php echo do_shortcode('[contact-form-7 id="89" title="Sams Contact form"]'); ?>
</div>


<?php

get_footer();

?>