<?php /*Template Name: ContactPage */


get_header();
?>

<div class="testing">
    <h1>CONTACT ME</h1>

    <?php echo do_shortcode('[contact-form-7 id="33" title="Contact Me Form"]'); ?>
</div>


<?php

get_footer();

?>