<?php /*Template Name: ContactFromPage */


get_header();
?>

<div class="testing">
    <h1>Copntact Form Page</h1>

    <h2>STILL WORKING ON THIS PAGE GIVE ME TIME - JUSTIN</h2>
</div>


<?php

get_footer();
