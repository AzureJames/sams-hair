<?php /*Template Name: HomePage */


get_header();
?>
<div class="testing">
    <h1>HAIR BY SAM KWETIO</h1>
    <p>Proud to offer many service combinations and options, this is a sample of what is offered in salon. These services and prices are for existing clients. If you're a new guest, definitely check out the New Guest Page for helpful details.</p>


    <h2>Most Popular Services</h2>
    <p>Get a Custom Clipper cut for a quick or short haircut when you need to freshen up, or go for a Signature Scissor cut for long or thick hair, or you're looking for something new. </p>
    <p>Add some colour to your style. I do everything from solid colours to complete total transformations and touchups.</p>
    <p>Get the longer hair you always wanted without waiting to grow it all out. Add extensions today!</p>

    <a href="">Contact Me</a>
</div>


<?php

get_footer();
